<nav class="navbar navbar-expand-lg navbar-dark bg-dark text-white">
  <div class="container-fluid">
    <a class="navbar-brand text-primary" href="#">Logo</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse bg-dark" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active fw-bold" aria-current="page" href="#">The Electionn</a>
        </li>
      </ul>

      <span>
        <ul class="navbar-nav me-auto mb-2 mb-lg-0 right-side">
          <li class="nav-item me-3">
            <a class="nav-link active border-bottom border-purple border-4" aria-current="page" href="#">Pasangan calon</a>
          </li>
          <li class="nav-item me-4">
            <a class="nav-link active text-secondary" aria-current="page" href="#">Hasil pemilihan</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active text-primary" aria-current="page" href="#"><i class="fas fa-user"></i></a>
          </li>
          
        </ul>
      </span>
     
    </div>
  </div>
</nav>