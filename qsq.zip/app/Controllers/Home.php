<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        $data = [
          'title' => 'Homepage'
        ];
        return view('homepage', $data);
    }
}
