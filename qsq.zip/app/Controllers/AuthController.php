<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\AuthModel;

class AuthController extends BaseController
{
    public function __construct()
    {
        $this->AuthModel = new AuthModel();
    }

    public function index()
    {

        // untuk register nanti
        $karakter = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789';
        $shuffle  = substr(str_shuffle($karakter), 0, 8);
    }

    public function login()
    {
        $data = [
            'title' => 'Form Login',
        ];

        return view('auth/login', $data);
    }

    public function postlogin()
    {
        $nis = $this->request->getVar('nis');
        $password = $this->request->getVar('password');

        $log = $this->AuthModel->getData($nis);
        if ($log == null) {
            return redirect()->to('/login');
        }

        if ($password == $log->password) {
            $data = [
                'login' => true,
                'nis' => $log->nis,
            ];
            session()->set($data);

            return redirect()->to('/')->with('msg', 'Berhasil Login');
        }
    }
}
