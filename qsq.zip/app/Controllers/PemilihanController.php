<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\DetailModel;

class PemilihanController extends BaseController
{

    public function __construct()
    {
        $this->DetailMode = new DetailModel();
    }

    public function index()
    {
        # code...
    }

    public function detail()
    {
        $data = [
            'title' => 'Detail'
        ];

        return view('pemilihan/detail', $data);
    }


    public function token()
    {
        $data = [
            'title' => 'Konfirmasi Token'
        ];

        return view('pemilihan/token', $data);
    }
}
